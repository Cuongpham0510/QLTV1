-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th3 17, 2021 lúc 04:34 PM
-- Phiên bản máy phục vụ: 10.4.16-MariaDB
-- Phiên bản PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `qltv`
--
CREATE DATABASE IF NOT EXISTS `qltv` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `qltv`;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ct_muontra`
--

CREATE TABLE `ct_muontra` (
  `maMuonTra` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maTL` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ghichu` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daTra` int(11) DEFAULT NULL,
  `ngayTra` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `muontra`
--

CREATE TABLE `muontra` (
  `maMuonTra` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maThe` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngayMuon` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tailieu`
--

CREATE TABLE `tailieu` (
  `maTL` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenTL` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tacGia` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theLoai` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NXB` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `namXB` int(11) DEFAULT NULL,
  `soLuong` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tailieu`
--

INSERT INTO `tailieu` (`maTL`, `tenTL`, `tacGia`, `theLoai`, `NXB`, `namXB`, `soLuong`) VALUES
('TL001', 'Cộng nghệ phần mềm', 'Nguyễn Trãi', 'Giáo trình', 'Hà Nội', 2000, 50);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thetv`
--

CREATE TABLE `thetv` (
  `maThe` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngayBD` date NOT NULL,
  `ngayKT` date DEFAULT NULL,
  `ghichu` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenDG` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lop` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `khoa` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ngaysinh` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `thetv`
--

INSERT INTO `thetv` (`maThe`, `ngayBD`, `ngayKT`, `ghichu`, `tenDG`, `lop`, `khoa`, `ngaysinh`) VALUES
('MT001', '2021-01-01', '2025-01-01', 'test', 'admin', '60TH', 'CNTT', '2000-07-02'),
('MT002', '2021-02-01', '2022-02-01', 'ko co gi', 'cuong', '60TH', 'CNTT', '2000-03-01'),
('MT003', '2022-02-01', '2023-02-01', 'ko co gi', 'dũng', '60TH', 'CNTT', '2000-03-01'),
('MT004', '2021-02-01', '2022-02-01', '', 'long', '60TH', 'CNTT', '2000-03-01'),
('MT005', '2021-02-01', '2025-02-01', 'thanh niên ảo tưởng', 'toàn', '60TH', 'CNTT', '2000-03-01'),
('MT006', '2021-02-01', '2023-02-01', 'zai phố cổ', 'minh ốc', '60KT', 'KT', '2000-03-01');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `ct_muontra`
--
ALTER TABLE `ct_muontra`
  ADD PRIMARY KEY (`maMuonTra`,`maTL`),
  ADD KEY `maTL` (`maTL`);

--
-- Chỉ mục cho bảng `muontra`
--
ALTER TABLE `muontra`
  ADD PRIMARY KEY (`maMuonTra`,`maThe`),
  ADD KEY `maThe` (`maThe`);

--
-- Chỉ mục cho bảng `tailieu`
--
ALTER TABLE `tailieu`
  ADD PRIMARY KEY (`maTL`);

--
-- Chỉ mục cho bảng `thetv`
--
ALTER TABLE `thetv`
  ADD PRIMARY KEY (`maThe`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `ct_muontra`
--
ALTER TABLE `ct_muontra`
  ADD CONSTRAINT `ct_muontra_ibfk_1` FOREIGN KEY (`maMuonTra`) REFERENCES `muontra` (`maMuonTra`),
  ADD CONSTRAINT `ct_muontra_ibfk_2` FOREIGN KEY (`maTL`) REFERENCES `tailieu` (`maTL`);

--
-- Các ràng buộc cho bảng `muontra`
--
ALTER TABLE `muontra`
  ADD CONSTRAINT `muontra_ibfk_1` FOREIGN KEY (`maThe`) REFERENCES `thetv` (`maThe`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
